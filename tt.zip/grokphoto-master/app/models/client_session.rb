class ClientSession < Authlogic::Session::Base
  # configuration here, see documentation for sub modules of Authlogic::Session
end